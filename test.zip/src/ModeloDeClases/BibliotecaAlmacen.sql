CREATE TABLE Libro (
    idlibro SERIAL PRIMARY KEY,
    nombre VARCHAR(50) NOT NULL UNIQUE,
    autor VARCHAR(50),
    isbn VARCHAR(13) NOT NULL UNIQUE,
    publicacion DATE NOT NULL,
    editorial VARCHAR(50) NOT NULL,
    cantidad INTEGER NOT NULL
);

CREATE TABLE Cliente (
    idcliente SERIAL PRIMARY KEY,
    nombres VARCHAR(50) NOT NULL,
    apellidos VARCHAR(50) NOT NULL,
    identificador VARCHAR(50) NOT NULL UNIQUE,
    direccion VARCHAR(50) NOT NULL,
    telefono VARCHAR(50) NOT NULL,
    tiene_libro_alquilado BOOLEAN DEFAULT FALSE
);


CREATE TABLE Administrador (
    idadministrador SERIAL PRIMARY KEY,
    nombres VARCHAR(50) NOT NULL,
    apellidos VARCHAR(50) NOT NULL,
    identificador VARCHAR(50) NOT NULL UNIQUE,
    direccion VARCHAR(50) NOT NULL,
    telefono VARCHAR(50) NOT NULL
);




INSERT INTO Cliente (nombres, apellidos, identificador, direccion, telefono) 
VALUES ('Miguel José', 'García León', '2345431d', '5av. lote 4 zona 3. San Juan', '5434874');

INSERT INTO Libro (nombre, autor, isbn, publicacion, editorial, cantidad) 
VALUES ('El viaje del tiempo', 'María López', '9781234567890', '2024-05-14', 'Horizontes Literarios', 10);

INSERT INTO Administrador (nombres, apellidos, identificador, direccion, telefono)
VALUES ('Ramon Miguel', 'Juarez Chajon', '03948544', '9av. zona 14 Cerro de la cruz', '7892449');



INSERT INTO Libro (nombre, autor, isbn, publicacion, editorial, cantidad)
VALUES 
    ('El misterio de la noche', 'Juan García', '9782345678901', '2023-08-20', 'Ediciones Estelares', 50),
    ('La sombra del pasado', 'Ana Martínez', '9783456789012', '2022-11-05', 'Editorial del Sur', 67),
    ('Aventuras en el espacio', 'Pedro Pérez', '9784567890123', '2024-02-10', 'Ediciones Galácticas', 23),
    ('El secreto del bosque', 'Luisa Sánchez', '9785678901234', '2023-04-15', 'Editorial del Bosque', 12),
    ('La isla perdida', 'Marcela Gómez', '9786789012345', '2022-09-30', 'Ediciones Náuticas', 34),
    ('El tesoro de los piratas', 'Javier Ruiz', '9787890123456', '2024-01-22', 'Editorial del Mar', 45),
    ('La ciudad de cristal', 'Elena Rodríguez', '9788901234567', '2023-12-18', 'Ediciones Cristalinas', 67),
    ('El ladrón de sueños', 'David Fernández', '9789012345678', '2022-07-07', 'Editorial de los Sueños', 23),
    ('Los secretos del desierto', 'Raquel Pérez', '9780123456789', '2024-06-28', 'Ediciones del Desierto', 34),
    ('El vuelo de la mariposa', 'Carlos Gómez', '9780987654321', '2023-03-12', 'Editorial Alada', 43),
    ('El último caballero', 'Lucía Martínez', '9789876543210', '2022-10-09', 'Ediciones Medievales', 90),
    ('El hechizo de la Luna', 'Mario García', '9788888888888', '2024-04-01', 'Editorial Lunar', 56),
    ('La noche de los vampiros', 'Sofía Ruiz', '9787777777777', '2023-07-19', 'Ediciones Oscuras', 67),
    ('El jardín de las hadas', 'Diego Rodríguez', '9786666666666', '2022-12-25', 'Editorial Encantada', 45),
    ('El secreto del faro', 'Isabel Pérez', '9785555555555', '2024-03-30', 'Ediciones Faro', 65),
    ('La maldición del castillo', 'Andrea López', '9784444444444', '2023-05-05', 'Editorial de los Castillos', 32),
    ('La leyenda del unicornio', 'Gabriel Gómez', '9783333333333', '2022-08-14', 'Ediciones Mágicas', 8),
    ('El árbol de la vida', 'María Martínez', '9782222222222', '2024-02-02', 'Editorial Vital', 4),
    ('La rebelión de los robots', 'Hugo Pérez', '9781111111111', '2023-09-17', 'Ediciones Tecnológicas', 34),
    ('El misterio de la pirámide', 'Laura Gómez', '9780000000000', '2022-04-08', 'Editorial Antigua', 65),
    ('El poder del fuego', 'Antonio Rodríguez', '9789999999999', '2024-07-11', 'Ediciones Ígneas', 23),
    ('La canción del mar', 'Marta Pérez', '9781112223334', '2023-01-30', 'Editorial Acuática', 85),
    ('El laberinto de los sueños', 'Javier Martínez', '9784445556667', '2022-06-22', 'Ediciones oníricas', 62),
    ('La ciudad de los monstruos', 'Ana García', '9781234567899', '2024-05-14', 'Editorial Monstruosa', 92),
    ('El prisionero de Azkaban', 'J.K. Rowling', '9780439136365', '1999-09-08', 'Bloomsbury Publishing', 48),
    ('Cien años de soledad', 'Gabriel García Márquez', '9788437610767', '1967-05-30', 'Editorial Sudamericana', 18),
    ('Harry Potter y la piedra filosofal', 'J.K. Rowling', '9788478884453', '1997-06-26', 'Bloomsbury Publishing', 84),
    ('El señor de los anillos', 'J.R.R. Tolkien', '9780345538376', '1954-07-29', 'Allen & Unwin', 74),
    ('Matar a un ruiseñor', 'Harper Lee', '9780061120084', '1960-07-11', 'J.B. Lippincott & Co.', 23);


SELECT * FROM Cliente;
Select * From Administrador;
SELECT * FROM Libro;


DROP TABLE IF EXISTS Libro CASCADE;
DROP TABLE IF EXISTS Cliente CASCADE;
DROP TABLE IF EXISTS Administrador CASCADE;