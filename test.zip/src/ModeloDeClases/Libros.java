package ModeloDeClases;

import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;

public class Libros {
    private SimpleStringProperty nombre;
    private SimpleStringProperty autor;
    private SimpleStringProperty ISBN;
    private SimpleStringProperty publicacion;
    private SimpleStringProperty editorial;
    private SimpleIntegerProperty cantidad;

    public Libros() {
        this.nombre = new SimpleStringProperty();
        this.autor = new SimpleStringProperty();
        this.ISBN = new SimpleStringProperty();
        this.publicacion = new SimpleStringProperty();
        this.editorial = new SimpleStringProperty();
        this.cantidad = new SimpleIntegerProperty();
    }

    public Libros(String nombre, String autor, String ISBN, String publicacion, String editorial, int cantidad) {
        this.nombre = new SimpleStringProperty(nombre);
        this.autor = new SimpleStringProperty(autor);
        this.ISBN = new SimpleStringProperty(ISBN);
        this.publicacion = new SimpleStringProperty(publicacion);
        this.editorial = new SimpleStringProperty(editorial);
        this.cantidad = new SimpleIntegerProperty(cantidad);
    }

    public String getNombre() {
        return nombre.get();
    }

    public void setNombre(String nombre) {
        this.nombre.set(nombre);
    }

    public SimpleStringProperty nombreProperty() {
        return nombre;
    }

    public String getAutor() {
        return autor.get();
    }

    public void setAutor(String autor) {
        this.autor.set(autor);
    }

    public SimpleStringProperty autorProperty() {
        return autor;
    }

    public String getISBN() {
        return ISBN.get();
    }

    public void setISBN(String ISBN) {
        this.ISBN.set(ISBN);
    }

    public SimpleStringProperty ISBNProperty() {
        return ISBN;
    }

    public String getPublicacion() {
        return publicacion.get();
    }

    public void setPublicacion(String publicacion) {
        this.publicacion.set(publicacion);
    }

    public SimpleStringProperty publicacionProperty() {
        return publicacion;
    }

    public String getEditorial() {
        return editorial.get();
    }

    public void setEditorial(String editorial) {
        this.editorial.set(editorial);
    }

    public SimpleStringProperty editorialProperty() {
        return editorial;
    }

    public int getCantidad() {
        return cantidad.get();
    }

    public void setCantidad(int cantidad) {
        this.cantidad.set(cantidad);
    }

    public SimpleIntegerProperty cantidadProperty() {
        return cantidad;
    }

    @Override
    public String toString() {
        return "Libros{" + "nombre=" + nombre.get() + ", autor=" + autor.get() + ", ISBN=" + ISBN.get() + ", publicacion=" + publicacion.get() + ", editorial=" + editorial.get() + ", cantidad=" + cantidad.get() + '}';
    }
}
