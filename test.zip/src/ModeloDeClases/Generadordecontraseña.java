
package ModeloDeClases;
import java.security.SecureRandom;

public class Generadordecontraseña {    
    // Método para generar la contraseña aleatoria
    public static String generarContrasena() {
        // Caracteres válidos para la contraseña
        String caracteres = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
        StringBuilder contrasena = new StringBuilder();
        SecureRandom random = new SecureRandom();
        
        // Generar la contraseña con 10 caracteres aleatorios
        for (int i = 0; i < 10; i++) {
            int index = random.nextInt(caracteres.length());
            contrasena.append(caracteres.charAt(index));
        }
        
        return contrasena.toString();
    }
    
    // Método main para probar el generador de contraseñas
    public static void main(String[] args) {
        String contrasenaGenerada = generarContrasena();
        System.out.println("Contraseña generada: " + contrasenaGenerada);
    }
}


