package ModeloDeClases;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.control.Alert;

public class ClienteConexionB {
    private final String url = "jdbc:postgresql://localhost:5432/clientes_biblioteca";
    private final String user = "postgres";
    private final String password = "garcia123";
    public static String nombreUsuario = "";

    public Connection conectar() {
        Connection conn = null;
        try {
            Class.forName("org.postgresql.Driver");
            conn = DriverManager.getConnection(url, user, password);
        } catch (ClassNotFoundException e) {
            System.out.println("Error: No se encontró el controlador de PostgreSQL: " + e.getMessage());
        } catch (SQLException e) {
            System.out.println("Error al conectar a la base de datos: " + e.getMessage());
        }
        return conn;
    }

    public void insertarCliente(String nombres, String apellidos, String identificador, String direccion, String telefono) {
        String SQL = "INSERT INTO Cliente(nombres, apellidos, identificador, direccion, telefono) VALUES(?, ?, ?, ?, ?)";

        try (Connection conn = conectar();
             PreparedStatement pstmt = conn.prepareStatement(SQL)) {

            pstmt.setString(1, nombres);
            pstmt.setString(2, apellidos);
            pstmt.setString(3, identificador);
            pstmt.setString(4, direccion);
            pstmt.setString(5, telefono);
            pstmt.executeUpdate();

            System.out.println("Cliente insertado con éxito");
        } catch (SQLException ex) {
            System.out.println("Error al insertar el cliente: " + ex.getMessage());
        }
    }

    public Usuarios obtenerUsuario(String identificador) {
        String SQL = "SELECT nombres, apellidos, direccion, telefono FROM Cliente WHERE identificador = ?";
        Usuarios usuario = null;

        try (Connection conn = conectar();
             PreparedStatement pstmt = conn.prepareStatement(SQL)) {

            pstmt.setString(1, identificador);
            ResultSet rs = pstmt.executeQuery();

            if (rs.next()) {
                String nombres = rs.getString("nombres");
                String apellidos = rs.getString("apellidos");
                String direccion = rs.getString("direccion");
                String telefono = rs.getString("telefono");
                usuario = new Usuarios(nombres, apellidos, telefono, direccion, identificador);

                // Actualizar el nombre de usuario
                setNombreUsuario(nombres);
            }
        } catch (SQLException ex) {
            System.out.println("Error al obtener el usuario: " + ex.getMessage());
        }
        return usuario;
    }
     public ObservableList<Usuarios> obtenerUsuarios() {
        ObservableList<Usuarios> usuarios = FXCollections.observableArrayList();
        String SQL = "SELECT * FROM Cliente";
        try (Connection conn = conectar();
             PreparedStatement pstmt = conn.prepareStatement(SQL);
             ResultSet rs = pstmt.executeQuery()) {

            while (rs.next()) {
                usuarios.add(new Usuarios(rs.getString("nombres"), rs.getString("apellidos"), rs.getString("telefono"), rs.getString("direccion"), rs.getString("identificador")));
            }
        } catch (SQLException ex) {
            System.out.println("Error al obtener los usuarios: " + ex.getMessage());
        }
        return usuarios;
    }

    public void actualizarUsuario(Usuarios usuario, String identificadorAntiguo) {
        String SQL = "UPDATE Cliente SET nombres = ?, apellidos = ?, telefono = ?, direccion = ?, identificador = ? WHERE identificador = ?";
        try (Connection conn = conectar();
             PreparedStatement pstmt = conn.prepareStatement(SQL)) {

            pstmt.setString(1, usuario.getNombre());
            pstmt.setString(2, usuario.getApellido());
            pstmt.setString(3, usuario.getTelefono());
            pstmt.setString(4, usuario.getDireccion());
            pstmt.setString(5, usuario.getIdentificador());
            pstmt.setString(6, identificadorAntiguo);

            int rowsAffected = pstmt.executeUpdate();
            if (rowsAffected > 0) {
                System.out.println("Usuario actualizado exitosamente.");
            } else {
                System.out.println("No se pudo actualizar el usuario. El identificador no existe.");
            }
        } catch (SQLException ex) {
            System.out.println("Error al actualizar el usuario: " + ex.getMessage());
        }
    }

    public void eliminarUsuario(Usuarios usuario) {
        String SQL = "DELETE FROM Cliente WHERE identificador = ?";
        try (Connection conn = conectar();
             PreparedStatement pstmt = conn.prepareStatement(SQL)) {

            pstmt.setString(1, usuario.getIdentificador());

            int rowsAffected = pstmt.executeUpdate();
            if (rowsAffected > 0) {
                System.out.println("Usuario eliminado exitosamente.");
            } else {
                System.out.println("No se pudo eliminar el usuario. El identificador no existe.");
            }
        } catch (SQLException ex) {
            System.out.println("Error al eliminar el usuario: " + ex.getMessage());
        }
    }

 public void insertarLibro(Libros libro) {
    String sql = "INSERT INTO Libro (nombre, autor, isbn, publicacion, editorial, cantidad) VALUES (?, ?, ?, ?, ?, ?)";

    try (Connection conn = conectar();
         PreparedStatement pstmt = conn.prepareStatement(sql)) {

        pstmt.setString(1, libro.getNombre());
        pstmt.setString(2, libro.getAutor());
        pstmt.setString(3, libro.getISBN());
        pstmt.setDate(4, java.sql.Date.valueOf(libro.getPublicacion()));
        pstmt.setString(5, libro.getEditorial());
        pstmt.setInt(6, libro.getCantidad());

        pstmt.executeUpdate();
        System.out.println("Libro insertado con éxito");

    } catch (SQLException e) {
        System.out.println("Error al insertar el libro: " + e.getMessage());
    }
}


    public ObservableList<Libros> obtenerLibros() {
        ObservableList<Libros> libros = FXCollections.observableArrayList();
        String SQL = "SELECT nombre, autor, ISBN, editorial, publicacion, cantidad FROM Libro";

        try (Connection conn = conectar();
             PreparedStatement pstmt = conn.prepareStatement(SQL);
             ResultSet rs = pstmt.executeQuery()) {

            while (rs.next()) {
                String nombre = rs.getString("nombre");
                String autor = rs.getString("autor");
                String ISBN = rs.getString("ISBN");
                String editorial = rs.getString("editorial");
                String publicacion = rs.getString("publicacion");
                int cantidad = rs.getInt("cantidad");
                libros.add(new Libros(nombre, autor, ISBN, publicacion, editorial, cantidad));
            }
        } catch (SQLException ex) {
            System.out.println("Error al obtener los libros: " + ex.getMessage());
            ex.printStackTrace();
        }
        return libros;
    }

    public void actualizarLibro(Libros libro) {
        String query = "UPDATE Libro SET nombre = ?, autor = ?, ISBN = ?, publicacion = ?, editorial = ?, cantidad = ? WHERE ISBN = ?";

        Connection conn = null;
        PreparedStatement stmt = null;

        try {
            conn = conectar();
            conn.setAutoCommit(false); // Desactivar la confirmación automática de la transacción

            stmt = conn.prepareStatement(query);
            stmt.setString(1, libro.getNombre());
            stmt.setString(2, libro.getAutor());
            stmt.setString(3, libro.getISBN());

            // Convertir la fecha de String a Date
            SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
            java.util.Date parsedDate = dateFormat.parse(libro.getPublicacion());
            java.sql.Date sqlDate = new java.sql.Date(parsedDate.getTime());
            stmt.setDate(4, sqlDate); // Asignar la fecha convertida al PreparedStatement

            stmt.setString(5, libro.getEditorial());
            stmt.setInt(6, libro.getCantidad());
            stmt.setString(7, libro.getISBN());  // Assuming ISBN is the unique identifier

            int rowsAffected = stmt.executeUpdate();
            if (rowsAffected > 0) {
                System.out.println("Libro actualizado con éxito");
                conn.commit(); // Confirmar la transacción
            } else {
                System.out.println("No se pudo actualizar el libro. El ISBN no existe.");
            }
        } catch (SQLException | ParseException ex) {
            System.out.println("Error al actualizar el libro: " + ex.getMessage());
            if (conn != null) {
                try {
                    conn.rollback(); // Deshacer la transacción en caso de error
                } catch (SQLException e) {
                    System.out.println("Error al deshacer la transacción: " + e.getMessage());
                }
            }
        } finally {
            // Cerrar recursos
            if (stmt != null) {
                try {
                    stmt.close();
                } catch (SQLException e) {
                    System.out.println("Error al cerrar el statement: " + e.getMessage());
                }
            }
            if (conn != null) {
                try {
                    conn.setAutoCommit(true); // Restaurar la confirmación automática de la transacción
                    conn.close();
                } catch (SQLException e) {
                    System.out.println("Error al cerrar la conexión: " + e.getMessage());
                }
            }
        }
    }

    public boolean verificarExistenciaLibro(String nombreOISBN) {
        String SQL = "SELECT * FROM Libro WHERE nombre = ? OR ISBN = ?";
        try (Connection conn = conectar();
             PreparedStatement pstmt = conn.prepareStatement(SQL)) {

            pstmt.setString(1, nombreOISBN);
            pstmt.setString(2, nombreOISBN);

            ResultSet rs = pstmt.executeQuery();

            return rs.next();
        } catch (SQLException ex) {
            System.out.println("Error al verificar la existencia del libro: " + ex.getMessage());
        }
        return false;
    }

    public Libros obtenerLibro(String nombreOISBN) {
        String SQL = "SELECT * FROM Libro WHERE nombre = ? OR ISBN = ?";
        Libros libro = null;

        try (Connection conn = conectar();
             PreparedStatement pstmt = conn.prepareStatement(SQL)) {

            pstmt.setString(1, nombreOISBN);
            pstmt.setString(2, nombreOISBN);
            ResultSet rs = pstmt.executeQuery();

            if (rs.next()) {
                String nombre = rs.getString("nombre");
                String autor = rs.getString("autor");
                String ISBN = rs.getString("ISBN");
                String editorial = rs.getString("editorial");
                String publicacion = rs.getString("publicacion");
                int cantidad = rs.getInt("cantidad");
                libro = new Libros(nombre, autor, ISBN, publicacion, editorial, cantidad);
            }
        } catch (SQLException ex) {
            System.out.println("Error al obtener el libro: " + ex.getMessage());
        }
        return libro;
    }

    public boolean usuarioTieneLibroAlquilado(String identificador) {
        String SQL = "SELECT tiene_libro_alquilado FROM Cliente WHERE identificador = ?";
        try (Connection conn = conectar();
             PreparedStatement pstmt = conn.prepareStatement(SQL)) {

            pstmt.setString(1, identificador);
            ResultSet rs = pstmt.executeQuery();

            if (rs.next()) {
                return rs.getBoolean("tiene_libro_alquilado");
            }
        } catch (SQLException ex) {
            System.out.println("Error al verificar el estado de alquiler del usuario: " + ex.getMessage());
        }
        return false;
    }

    public void actualizarEstadoAlquilerUsuario(String identificador, boolean estado) {
        String SQL = "UPDATE Cliente SET tiene_libro_alquilado = ? WHERE identificador = ?";
        try (Connection conn = conectar();
             PreparedStatement pstmt = conn.prepareStatement(SQL)) {

            pstmt.setBoolean(1, estado);
            pstmt.setString(2, identificador);
            pstmt.executeUpdate();
        } catch (SQLException ex) {
            System.out.println("Error al actualizar el estado de alquiler del usuario: " + ex.getMessage());
        }
    }

    public boolean usuarioExiste(String identificador) {
        String SQL = "SELECT 1 FROM Cliente WHERE identificador = ?";
        try (Connection conn = conectar();
             PreparedStatement pstmt = conn.prepareStatement(SQL)) {

            pstmt.setString(1, identificador);
            ResultSet rs = pstmt.executeQuery();

            return rs.next();
        } catch (SQLException ex) {
            System.out.println("Error al verificar el usuario: " + ex.getMessage());
        }
        return false;
    }

    public void actualizarCantidadLibro(Libros libro) {
        String SQL = "UPDATE Libro SET cantidad = ? WHERE ISBN = ?";
        try (Connection conn = conectar();
             PreparedStatement pstmt = conn.prepareStatement(SQL)) {

            pstmt.setInt(1, libro.getCantidad());
            pstmt.setString(2, libro.getISBN());
            pstmt.executeUpdate();

            System.out.println("Cantidad de libros actualizada con éxito");
        } catch (SQLException ex) {
            System.out.println("Error al actualizar la cantidad de libros: " + ex.getMessage());
        }
    }

    public Libros obtenerLibroPorNombreOISBN(String nombreOISBN) {
        String SQL = "SELECT * FROM Libro WHERE nombre = ? OR ISBN = ?";
        Libros libro = null;

        try (Connection conn = conectar();
             PreparedStatement pstmt = conn.prepareStatement(SQL)) {

            pstmt.setString(1, nombreOISBN);
            pstmt.setString(2, nombreOISBN);
            ResultSet rs = pstmt.executeQuery();

            if (rs.next()) {
                libro = new Libros(
                    rs.getString("nombre"),
                    rs.getString("autor"),
                    rs.getString("ISBN"),
                    rs.getString("publicacion"),
                    rs.getString("editorial"),
                    rs.getInt("cantidad")
                );
            }
        } catch (SQLException ex) {
            System.out.println("Error al obtener el libro: " + ex.getMessage());
        }
        return libro;
    }

    public void disminuirCantidadLibro(String ISBN, int cantidad) {
        String SQL = "UPDATE Libro SET cantidad = cantidad - ? WHERE ISBN = ?";
        try (Connection conn = conectar();
             PreparedStatement pstmt = conn.prepareStatement(SQL)) {

            pstmt.setInt(1, cantidad);
            pstmt.setString(2, ISBN);
            pstmt.executeUpdate();

            System.out.println("Cantidad de libros disminuida con éxito");
        } catch (SQLException ex) {
            System.out.println("Error al disminuir la cantidad de libros: " + ex.getMessage());
        }
    }

    public void aumentarCantidadLibro(String ISBN, int cantidad) {
        String SQL = "UPDATE Libro SET cantidad = cantidad + ? WHERE ISBN = ?";
        try (Connection conn = conectar();
             PreparedStatement pstmt = conn.prepareStatement(SQL)) {

            pstmt.setInt(1, cantidad);
            pstmt.setString(2, ISBN);
            pstmt.executeUpdate();

            System.out.println("Cantidad de libros aumentada con éxito");
        } catch (SQLException ex) {
            System.out.println("Error al aumentar la cantidad de libros: " + ex.getMessage());
        }
    }

    public Libros obtenerLibroPorUsuario(String identificadorUsuario) {
    String SQL = "SELECT * FROM Libro WHERE ISBN IN (SELECT ISBN FROM Alquiler WHERE identificador_usuario = ?)";
    Libros libro = null;

    try (Connection conn = conectar();
         PreparedStatement pstmt = conn.prepareStatement(SQL)) {

        pstmt.setString(1, identificadorUsuario);
        ResultSet rs = pstmt.executeQuery();

        if (rs.next()) {
            libro = new Libros(
                rs.getString("nombre"),
                rs.getString("autor"),
                rs.getString("ISBN"),
                rs.getString("publicacion"),
                rs.getString("editorial"),
                rs.getInt("cantidad")
            );
        }
    } catch (SQLException ex) {
        System.out.println("Error al obtener el libro alquilado por el usuario: " + ex.getMessage());
    }
    return libro;
}

public void eliminarLibro(Libros libro) {
    String SQL = "DELETE FROM Libro WHERE ISBN = ?";
    try (Connection conn = conectar();
         PreparedStatement pstmt = conn.prepareStatement(SQL)) {

        pstmt.setString(1, libro.getISBN());
        int rowsAffected = pstmt.executeUpdate();

        if (rowsAffected > 0) {
            System.out.println("Libro eliminado con éxito");
        } else {
            System.out.println("No se pudo eliminar el libro. El ISBN no existe.");
        }
    } catch (SQLException ex) {
        System.out.println("Error al eliminar el libro: " + ex.getMessage());
    }
}
public void eliminarRegistroAlquiler(String identificadorUsuario, String ISBN) {
        String SQL = "DELETE FROM Alquiler WHERE identificador_usuario = ? AND ISBN = ?";
        
        try (Connection conn = conectar();
             PreparedStatement pstmt = conn.prepareStatement(SQL)) {
            
            pstmt.setString(1, identificadorUsuario);
            pstmt.setString(2, ISBN);
            
            int affectedRows = pstmt.executeUpdate();
            
            if (affectedRows == 0) {
                System.out.println("No se encontró un registro de alquiler para eliminar.");
            } else {
                System.out.println("Registro de alquiler eliminado con éxito.");
            }
            
        } catch (SQLException ex) {
            System.out.println("Error al eliminar el registro de alquiler: " + ex.getMessage());
        }
    }
    public void setNombreUsuario(String nombre) {
        nombreUsuario = nombre;
    }

}


