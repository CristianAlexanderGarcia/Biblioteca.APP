package ModeloDeClases;

import java.sql.Connection;

public class MainConexion {

    public static void main(String[] args) {
        ClienteConexionB clienteConexionB = new ClienteConexionB();
        
        // Prueba de conexión
        Connection conn = clienteConexionB.conectar();
        if (conn != null) {
            System.out.println("Conexión establecida desde ConexionBD");
        } else {
            System.out.println("No se pudo establecer la conexión desde ConexionBD");
            return; // Si no se pudo conectar, no tiene sentido continuar
        }

        // Guardar un cliente
        clienteConexionB.insertarCliente("Juan", "Perez", "123456789", "Calle Falsa 123", "555-1234");
    }
}
