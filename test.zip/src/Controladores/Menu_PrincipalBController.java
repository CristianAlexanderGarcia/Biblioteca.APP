package Controladores;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.stage.Stage;

public class Menu_PrincipalBController implements Initializable {

    @FXML
    private Button BotonBuscar;
    @FXML
    private Button BotonAlmacen;
    @FXML
    private Button BotonHistorial;
    @FXML
    private Button BotonSalir;
    @FXML
    private Button Usuario;

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }

    @FXML
    private void botonParaverAlUsuario(ActionEvent event) throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("/InterfacesGraficas/Menu_Usuario.fxml"));
        Parent root = loader.load();

        // Obtener el controlador de la nueva escena
        Menu_UsuarioController usuarioController = loader.getController();
        
        // Pasar el identificador del usuario
        String identificadorUsuario = PantallaDeIngresoController.identificadorUsuario;
        usuarioController.setIdentificadorUsuario(identificadorUsuario);
        
        Scene scene = new Scene(root);
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setScene(scene);
        stage.show();
    }

   @FXML
private void botonParaBuscarLibros(ActionEvent event) {
    try {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("/InterfacesGraficas/Menu_Busqueda.fxml"));
        Parent root = loader.load();
        Scene scene = new Scene(root);
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setScene(scene);
        stage.show();
        System.out.println("Cambio de escena realizado"); // Añadir mensaje de depuración
    } catch (IOException e) {
        System.out.println("Error al cargar la ventana de búsqueda: " + e.getMessage());
        e.printStackTrace(); // Imprimir el stack trace para más detalles
    }
}


    @FXML
    private void botonParaverElAlmacen(ActionEvent event) throws IOException {
        try {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("/InterfacesGraficas/AlmacenB.fxml"));
        Parent root = loader.load();
        Scene scene = new Scene(root);
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setScene(scene);
        stage.show();
        System.out.println("Cambio de escena realizado"); // Añadir mensaje de depuración
    } catch (IOException e) {
        System.out.println("Error al cargar la ventana de búsqueda: " + e.getMessage());
        e.printStackTrace(); // Imprimir el stack trace para más detalles
    }
    }

    @FXML
    private void botonParaverElHistorial(ActionEvent event) throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("/InterfacesGraficas/Menu_Historial.fxml"));
        Parent root = loader.load();
        Scene scene = new Scene(root);
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setScene(scene);
        stage.show();
    }

    @FXML
    private void botonParaSalir(ActionEvent event) {
        Stage stage = (Stage) ((javafx.scene.Node) event.getSource()).getScene().getWindow();
        stage.close();
        System.exit(0);
    }
}
