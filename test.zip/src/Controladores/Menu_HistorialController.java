package Controladores;

import ModeloDeClases.ClienteConexionB;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

public class Menu_HistorialController implements Initializable {

    @FXML
    private Button BotonDeRegreso;
    @FXML
    private TextField LibrosRentados;
    @FXML
    private TextField librosDevueltos;
    @FXML
    private TextField Recordatorios;
    @FXML
    private TextField multasGeneradas;
    @FXML
    private TextField nombre;

    // Referencia al controlador Menu_BusquedaController
    private Menu_BusquedaController menuBusquedaController;

    // Método para establecer la referencia al controlador Menu_BusquedaController
    public void setMenuBusquedaController(Menu_BusquedaController menuBusquedaController) {
        this.menuBusquedaController = menuBusquedaController;
        System.out.println("Menu_BusquedaController establecido");
        mostrarDatos();  // Mostrar datos una vez que el controlador de búsqueda esté establecido
    }

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // Se deja vacío porque mostrarDatos() se llamará cuando se establezca el controlador
        System.out.println("Menu_HistorialController inicializado");
    }

    @FXML
    private void BotonParaRegresarAmenuPrincipal(ActionEvent event) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/InterfacesGraficas/Menu_PrincipalB.fxml"));
            Parent root = loader.load();
            Scene scene = new Scene(root);
            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            stage.setScene(scene);
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // Método para mostrar los datos en los TextField
    private void mostrarDatos() {
        System.out.println("Mostrando datos...");
        if (menuBusquedaController != null) {
            // Mostrar el nombre del usuario
            nombre.setText(ClienteConexionB.nombreUsuario);
            System.out.println("Nombre: " + ClienteConexionB.nombreUsuario);

            // Mostrar la cantidad de libros rentados
            LibrosRentados.setText(String.valueOf(menuBusquedaController.getCantidadLibrosRentados()));
            System.out.println("Libros Rentados: " + menuBusquedaController.getCantidadLibrosRentados());

            // Mostrar la cantidad de libros devueltos
            librosDevueltos.setText(String.valueOf(menuBusquedaController.getCantidadLibrosDevueltos()));
            System.out.println("Libros Devueltos: " + menuBusquedaController.getCantidadLibrosDevueltos());

            // Mostrar la cantidad de recordatorios
            Recordatorios.setText(String.valueOf(menuBusquedaController.getCantidadRecordatorios()));
            System.out.println("Recordatorios: " + menuBusquedaController.getCantidadRecordatorios());

            // Mostrar la cantidad de multas generadas
            multasGeneradas.setText(String.valueOf(menuBusquedaController.getCantidadMultasGeneradas()));
            System.out.println("Multas Generadas: " + menuBusquedaController.getCantidadMultasGeneradas());
        } else {
            System.out.println("menuBusquedaController es null");
        }
    }
}
