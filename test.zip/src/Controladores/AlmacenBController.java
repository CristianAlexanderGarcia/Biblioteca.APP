package Controladores;

import ModeloDeClases.ClienteConexionB;
import ModeloDeClases.Libros;
import java.io.IOException;
import java.net.URL;
import java.util.Optional;
import java.util.ResourceBundle;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.TextInputDialog;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

public class AlmacenBController implements Initializable {

    @FXML
    private Button BotonRegresar;
    @FXML
    private Button BotonAlmacen;
    @FXML
    private TableView<Libros> TabladelAlmacen;
    @FXML
    private TableColumn<Libros, String> nombreColumn;
    @FXML
    private TableColumn<Libros, String> autorColumn;
    @FXML
    private TableColumn<Libros, String> ISBNColumn;
    @FXML
    private TableColumn<Libros, String> editorialColumn;
    @FXML
    private TableColumn<Libros, String> publicacionColumn;
    @FXML
    private TableColumn<Libros, Integer> cantidadColumn;

    private ClienteConexionB clienteConexionB;
    private static int librosDevueltosCantidad = 0; // Variable para rastrear la cantidad de libros devueltos

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        clienteConexionB = new ClienteConexionB(); // Crear una instancia de ClienteConexionB
        initializeTableColumns();
        cargarLibros();
    }

    private void initializeTableColumns() {
        nombreColumn.setCellValueFactory(new PropertyValueFactory<>("nombre"));
        autorColumn.setCellValueFactory(new PropertyValueFactory<>("autor"));
        ISBNColumn.setCellValueFactory(new PropertyValueFactory<>("ISBN"));
        editorialColumn.setCellValueFactory(new PropertyValueFactory<>("editorial"));
        publicacionColumn.setCellValueFactory(new PropertyValueFactory<>("publicacion"));
        cantidadColumn.setCellValueFactory(new PropertyValueFactory<>("cantidad"));
    }

    private void cargarLibros() {
        ObservableList<Libros> libros = clienteConexionB.obtenerLibros();
        TabladelAlmacen.setItems(libros);
    }

    @FXML
private void BotonRgresarLibros(ActionEvent event) {
    // Mostrar cuadro de diálogo para ingresar el nombre o ISBN del libro
    TextInputDialog dialogLibro = new TextInputDialog();
    dialogLibro.setTitle("Devolver libro");
    dialogLibro.setHeaderText("Introduce el nombre o ISBN del libro que alquilaste:");
    dialogLibro.setContentText("Nombre o ISBN:");
    Optional<String> resultLibro = dialogLibro.showAndWait();
    
    String nombreOISBN = "";
    if (resultLibro.isPresent()) {
        nombreOISBN = resultLibro.get();
    } else {
        return; // El usuario canceló, salir del método
    }

    // Mostrar cuadro de diálogo para ingresar la cantidad de libros devueltos
    TextInputDialog dialogCantidad = new TextInputDialog();
    dialogCantidad.setTitle("Devolver libro");
    dialogCantidad.setHeaderText("Introduce la cantidad de libros que devuelves:");
    dialogCantidad.setContentText("Cantidad:");
    Optional<String> resultCantidad = dialogCantidad.showAndWait();

    int cantidadDevuelta = 0;
    if (resultCantidad.isPresent()) {
        try {
            cantidadDevuelta = Integer.parseInt(resultCantidad.get());
        } catch (NumberFormatException e) {
            showAlert(Alert.AlertType.ERROR, "Error", "Cantidad inválida. Por favor, ingrese un número válido.");
            return;
        }
    } else {
        return; // El usuario canceló, salir del método
    }

    // Mostrar cuadro de diálogo para ingresar el identificador del usuario
    TextInputDialog dialogUsuario = new TextInputDialog();
    dialogUsuario.setTitle("Devolver libro");
    dialogUsuario.setHeaderText("Introduce tu identificador:");
    dialogUsuario.setContentText("Identificador:");
    Optional<String> resultUsuario = dialogUsuario.showAndWait();

    String identificadorUsuario = "";
    if (resultUsuario.isPresent()) {
        identificadorUsuario = resultUsuario.get();
    } else {
        return; // El usuario canceló, salir del método
    }

    // Verificar si el usuario existe y tiene un libro alquilado
    if (!clienteConexionB.usuarioTieneLibroAlquilado(identificadorUsuario)) {
        showAlert(Alert.AlertType.ERROR, "Error", "El usuario no tiene libros alquilados.");
        return;
    }

    // Obtener el libro de la base de datos
    Libros libro = clienteConexionB.obtenerLibro(nombreOISBN);
    if (libro == null) {
        showAlert(Alert.AlertType.ERROR, "Error", "El libro no existe en la base de datos.");
        return;
    }

    // Actualizar la cantidad de libros devueltos en el almacen
    clienteConexionB.aumentarCantidadLibro(libro.getISBN(), cantidadDevuelta);

    // Actualizar el estado del alquiler del usuario
    clienteConexionB.actualizarEstadoAlquilerUsuario(identificadorUsuario, false);

    // Eliminar el registro de alquiler
    clienteConexionB.eliminarRegistroAlquiler(identificadorUsuario, libro.getISBN());

    // Mostrar mensaje de éxito después de un pequeño retardo
    try {
        Thread.sleep(100);
    } catch (InterruptedException e) {
        e.printStackTrace();
    }
    showAlert(Alert.AlertType.INFORMATION, "Libro devuelto", "¡Libro devuelto con éxito!");

    // Recargar la tabla de libros
    cargarLibros();
}


    @FXML
    private void BotonRegresarAlInicio(ActionEvent event) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/InterfacesGraficas/Menu_PrincipalB.fxml"));
            Parent root = loader.load();
            Scene scene = new Scene(root);
            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            stage.setScene(scene);
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void showAlert(Alert.AlertType alertType, String title, String message) {
        Alert alert = new Alert(alertType);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    // Método para obtener la cantidad de libros devueltos
    public static int getLibrosDevueltos() {
        return librosDevueltosCantidad;
    }
    
}
