package Controladores;

import ModeloDeClases.ClienteConexionB;
import ModeloDeClases.Libros;
import javafx.collections.ObservableList;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;

public class ControladorUtilitario {

    public static void cargarLibros(ClienteConexionB clienteConexionB, TableView<Libros> tabla, 
            TableColumn<Libros, String> nombreColumn, 
            TableColumn<Libros, String> autorColumn, 
            TableColumn<Libros, String> ISBNColumn, 
            TableColumn<Libros, String> editorialColumn, 
            TableColumn<Libros, String> publicacionColumn, 
            TableColumn<Libros, Integer> cantidadColumn) {

        ObservableList<Libros> libros = clienteConexionB.obtenerLibros();
        nombreColumn.setCellValueFactory(new PropertyValueFactory<>("nombre"));
        autorColumn.setCellValueFactory(new PropertyValueFactory<>("autor"));
        ISBNColumn.setCellValueFactory(new PropertyValueFactory<>("ISBN"));
        editorialColumn.setCellValueFactory(new PropertyValueFactory<>("editorial"));
        publicacionColumn.setCellValueFactory(new PropertyValueFactory<>("publicacion"));
        cantidadColumn.setCellValueFactory(new PropertyValueFactory<>("cantidad"));
        tabla.setItems(libros);
    }
}
