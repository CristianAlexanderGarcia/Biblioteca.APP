package Controladores;

import ModeloDeClases.ClienteConexionB;
import ModeloDeClases.Libros;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.util.Optional;
import java.util.ResourceBundle;

public class Lista_LibrosController implements Initializable {

    @FXML
    private Button BotonRegreso;
    @FXML
    private TableView<Libros> TablaLibros;
    @FXML
    private TableColumn<Libros, String> nombreColum;
    @FXML
    private TableColumn<Libros, String> autorColum;
    @FXML
    private TableColumn<Libros, String> ISBNColum;
    @FXML
    private TableColumn<Libros, String> publicacionColum;
    @FXML
    private TableColumn<Libros, String> editorialColum;
    @FXML
    private TableColumn<Libros, Integer> cantidadColum;
    private TextField nombreField;
    private TextField autorField;
    private TextField ISBNField;
    private TextField publicacionField;
    private TextField editorialField;
    private TextField cantidadField;
    @FXML
    private Button BotonModificarLibro;

    private ClienteConexionB clienteConexionB;
    @FXML
    private Button ElimnarLibro;

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        clienteConexionB = new ClienteConexionB();
        nombreColum.setCellValueFactory(cellData -> cellData.getValue().nombreProperty());
        autorColum.setCellValueFactory(cellData -> cellData.getValue().autorProperty());
        ISBNColum.setCellValueFactory(cellData -> cellData.getValue().ISBNProperty());
        publicacionColum.setCellValueFactory(cellData -> cellData.getValue().publicacionProperty());
        editorialColum.setCellValueFactory(cellData -> cellData.getValue().editorialProperty());
        cantidadColum.setCellValueFactory(cellData -> cellData.getValue().cantidadProperty().asObject());

        try {
            cargarLibros();
        } catch (SQLException ex) {
            System.out.println("Error al cargar los libros: " + ex.getMessage());
        }

        // Listener para actualizar los campos de texto cuando se seleccione un libro en la tabla
        TablaLibros.getSelectionModel().selectedItemProperty().addListener(
            (observable, oldValue, newValue) -> mostrarDetallesLibro(newValue));
    }

    private void mostrarDetallesLibro(Libros libro) {
        if (libro != null) {
            nombreField.setText(libro.getNombre());
            autorField.setText(libro.getAutor());
            ISBNField.setText(libro.getISBN());
            publicacionField.setText(libro.getPublicacion());
            editorialField.setText(libro.getEditorial());
            cantidadField.setText(Integer.toString(libro.getCantidad()));
        } else {
            nombreField.setText("");
            autorField.setText("");
            ISBNField.setText("");
            publicacionField.setText("");
            editorialField.setText("");
            cantidadField.setText("");
        }
    }

    private void cargarLibros() throws SQLException {
        ObservableList<Libros> libros = clienteConexionB.obtenerLibros();
        TablaLibros.setItems(libros);
    }

    @FXML
    private void BotonParaRegresarAlinicio(ActionEvent event) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/InterfacesGraficas/Menu_Principal_Administrador.fxml"));
            Parent root = loader.load();
            Scene scene = new Scene(root);
            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            stage.setScene(scene);
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

   @FXML
private void BotonParaModificarLos_Libros(ActionEvent event) {
    Libros libroSeleccionado = TablaLibros.getSelectionModel().getSelectedItem();
    if (libroSeleccionado != null) {
        // Mostrar un diálogo para seleccionar el campo a modificar
        ChoiceDialog<String> dialog = new ChoiceDialog<>("nombre", "nombre", "autor", "ISBN", "publicacion", "editorial", "cantidad");
        dialog.setTitle("Modificar Libro");
        dialog.setHeaderText("Seleccione el campo a modificar");
        dialog.setContentText("Campo:");

        String campoSeleccionado = dialog.showAndWait().orElse(null);
        if (campoSeleccionado != null) {
            // Mostrar un cuadro de texto para ingresar el nuevo valor
            TextInputDialog valorDialogo = new TextInputDialog();
            valorDialogo.setTitle("Modificar Libro");
            valorDialogo.setHeaderText("Ingrese el nuevo valor para " + campoSeleccionado);
            valorDialogo.setContentText("Nuevo valor:");

            String nuevoValor = valorDialogo.showAndWait().orElse(null);
            if (nuevoValor != null) {
                // Mostrar un cuadro de texto para ingresar el identificador del libro
                TextInputDialog identificadorDialogo = new TextInputDialog();
                identificadorDialogo.setTitle("Modificar Libro");
                identificadorDialogo.setHeaderText("Ingrese el identificador del libro");
                identificadorDialogo.setContentText("Identificador:");

                String identificador = identificadorDialogo.showAndWait().orElse(null);
                if (identificador != null) {
                    try {
                        // Verificar si el identificador existe en la tabla de libros
                        if (clienteConexionB.verificarExistenciaLibro(identificador)) {
                            // Actualizar el campo seleccionado del libro con el nuevo valor
                            switch (campoSeleccionado) {
                                case "nombre":
                                    libroSeleccionado.setNombre(nuevoValor);
                                    break;
                                case "autor":
                                    libroSeleccionado.setAutor(nuevoValor);
                                    break;
                                case "ISBN":
                                    libroSeleccionado.setISBN(nuevoValor);
                                    break;
                                case "publicacion":
                                    libroSeleccionado.setPublicacion(nuevoValor);
                                    break;
                                case "editorial":
                                    libroSeleccionado.setEditorial(nuevoValor);
                                    break;
                                case "cantidad":
                                    libroSeleccionado.setCantidad(Integer.parseInt(nuevoValor));
                                    break;
                            }

                            // Actualizar el libro en la base de datos
                            clienteConexionB.actualizarLibro(libroSeleccionado);

                            // Mostrar una alerta de éxito
                            mostrarAlerta("Éxito", "Libro modificado exitosamente.");
                        } else {
                            mostrarAlerta("Error", "El identificador no existe en la tabla de libros.");
                        }
                    } catch (NumberFormatException e) {
                        mostrarAlerta("Error", "El valor de cantidad debe ser un número entero.");
                    }
                }
            }
        }
    } else {
        // Si no se seleccionó ningún libro, mostrar una alerta
        mostrarAlerta("Error", "Por favor, seleccione un libro para modificar.");
    }
}
private void mostrarAlerta(String titulo, String mensaje) {
    Alert alert = new Alert(Alert.AlertType.INFORMATION);
    alert.setTitle(titulo);
    alert.setHeaderText(null);
    alert.setContentText(mensaje);
    alert.showAndWait();
}

   @FXML
private void BotonParaEliminarLibro(ActionEvent event) {
    // Obtener el libro seleccionado en la tabla
    Libros libroSeleccionado = TablaLibros.getSelectionModel().getSelectedItem();

    if (libroSeleccionado != null) {
        // Mostrar un diálogo de confirmación antes de eliminar el libro
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Confirmar Eliminación");
        alert.setHeaderText("¿Está seguro de que desea eliminar el libro seleccionado?");
        alert.setContentText("Esta acción no se puede deshacer.");

        // Obtener la respuesta del usuario
        Optional<ButtonType> result = alert.showAndWait();

        if (result.isPresent() && result.get() == ButtonType.OK) {
            // Si el usuario confirmó la eliminación, llamar al método de eliminación en ClienteConexionB
            clienteConexionB.eliminarLibro(libroSeleccionado);

            // Actualizar la tabla de libros después de la eliminación
            try {
                cargarLibros();
            } catch (SQLException ex) {
                System.out.println("Error al cargar los libros: " + ex.getMessage());
            }

            // Mostrar un mensaje de éxito
            mostrarAlerta("Éxito", "Libro eliminado exitosamente.");
        }
    } else {
        // Si no se seleccionó ningún libro, mostrar una alerta
        mostrarAlerta("Error", "Por favor, seleccione un libro para eliminar.");
    }
}


}
