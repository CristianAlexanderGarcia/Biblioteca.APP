package Controladores;

import ModeloDeClases.ClienteConexionB;
import ModeloDeClases.Usuarios;
import java.io.IOException;
import java.net.URL;
import java.util.Optional;
import java.util.ResourceBundle;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonBar;
import javafx.scene.control.ButtonType;
import javafx.scene.control.ChoiceDialog;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextInputDialog;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

public class Lista_De_UsuariosController implements Initializable {

    @FXML
    private Button BotonDeRegreso;
    @FXML
    private TableView<Usuarios> ListaDeUsuarios;
    @FXML
    private TableColumn<Usuarios, String> nombreColum;
    @FXML
    private TableColumn<Usuarios, String> apellidoColum;
    @FXML
    private TableColumn<Usuarios, String> telefonoColum;
    @FXML
    private TableColumn<Usuarios, String> direccionColum;
    @FXML
    private TableColumn<Usuarios, String> identificadorColum;
    @FXML
    private Button BotonParaEliminar;
    @FXML
    private Button BotonParaModificar;

    private ObservableList<Usuarios> listaUsuarios;

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // Configurar las columnas de la tabla
        nombreColum.setCellValueFactory(new PropertyValueFactory<>("nombre"));
        apellidoColum.setCellValueFactory(new PropertyValueFactory<>("apellido"));
        telefonoColum.setCellValueFactory(new PropertyValueFactory<>("telefono"));
        direccionColum.setCellValueFactory(new PropertyValueFactory<>("direccion"));
        identificadorColum.setCellValueFactory(new PropertyValueFactory<>("identificador"));

        // Cargar datos de la base de datos
        ClienteConexionB conexion = new ClienteConexionB();
        listaUsuarios = conexion.obtenerUsuarios();
        ListaDeUsuarios.setItems(listaUsuarios);
    }

    @FXML
    private void RegresarPantallaPrincipal(ActionEvent event) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/InterfacesGraficas/Menu_Principal_Administrador.fxml"));
            Parent root = loader.load();
            Scene scene = new Scene(root);
            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            stage.setScene(scene);
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @FXML
    private void ModificarUsuario(ActionEvent event) {
        Usuarios usuarioSeleccionado = ListaDeUsuarios.getSelectionModel().getSelectedItem();
        if (usuarioSeleccionado != null) {
            // Mostrar un diálogo para seleccionar el campo a modificar
            ChoiceDialog<String> dialog = new ChoiceDialog<>("nombre", "apellido", "telefono", "direccion", "identificador");
            dialog.setTitle("Modificar Usuario");
            dialog.setHeaderText("Seleccione el campo a modificar");
            dialog.setContentText("Campo:");

            Optional<String> result = dialog.showAndWait();
            result.ifPresent(campoSeleccionado -> {
                // Mostrar un cuadro de texto para ingresar el nuevo valor
                TextInputDialog valorDialogo = new TextInputDialog();
                valorDialogo.setTitle("Modificar Usuario");
                valorDialogo.setHeaderText("Ingrese el nuevo valor para " + campoSeleccionado);
                valorDialogo.setContentText("Nuevo valor:");

                Optional<String> newValue = valorDialogo.showAndWait();
                newValue.ifPresent(nuevoValor -> {
                    try {
                        // Guardar el identificador antiguo
                        String identificadorAntiguo = usuarioSeleccionado.getIdentificador();

                        // Actualizar el campo seleccionado del usuario con el nuevo valor
                        switch (campoSeleccionado) {
                            case "nombre":
                                usuarioSeleccionado.setNombre(nuevoValor);
                                break;
                            case "apellido":
                                usuarioSeleccionado.setApellido(nuevoValor);
                                break;
                            case "telefono":
                                usuarioSeleccionado.setTelefono(nuevoValor);
                                break;
                            case "direccion":
                                usuarioSeleccionado.setDireccion(nuevoValor);
                                break;
                            case "identificador":
                                usuarioSeleccionado.setIdentificador(nuevoValor);
                                break;
                        }

                        // Actualizar el usuario en la base de datos
                        ClienteConexionB conexion = new ClienteConexionB();
                        conexion.actualizarUsuario(usuarioSeleccionado, identificadorAntiguo);

                        // Mostrar una alerta de éxito
                        mostrarAlerta("Éxito", "Usuario modificado exitosamente.");

                        // Volver a cargar los datos de la base de datos para reflejar los cambios en la tabla
                        listaUsuarios.clear();
                        listaUsuarios.addAll(conexion.obtenerUsuarios());
                    } catch (Exception e) {
                        // Mostrar una alerta en caso de error
                        mostrarAlerta("Error", "Ha ocurrido un error al modificar el usuario.");
                    }
                });
            });
        } else {
            // Si no se seleccionó ningún usuario, mostrar una alerta
            mostrarAlerta("Error", "Por favor, seleccione un usuario para modificar.");
        }
    }

    @FXML
    private void EliminarUsuario(ActionEvent event) {
        Usuarios usuarioSeleccionado = ListaDeUsuarios.getSelectionModel().getSelectedItem();
        if (usuarioSeleccionado != null) {
            // Confirmar la eliminación del usuario
            Alert confirmacion = new Alert(Alert.AlertType.CONFIRMATION);
            confirmacion.setTitle("Eliminar Usuario");
            confirmacion.setHeaderText("¿Estás seguro de que deseas eliminar este usuario?");
            confirmacion.setContentText("identificador: " + usuarioSeleccionado.getIdentificador());

            ButtonType botonEliminar = new ButtonType("Eliminar");
            ButtonType botonCancelar = new ButtonType("Cancelar", ButtonBar.ButtonData.CANCEL_CLOSE);

            confirmacion.getButtonTypes().setAll(botonEliminar, botonCancelar);

            Optional<ButtonType> confirmResult = confirmacion.showAndWait();

            if (confirmResult.isPresent() && confirmResult.get() == botonEliminar) {
                // Eliminar el usuario de la base de datos
                ClienteConexionB conexion = new ClienteConexionB();
                conexion.eliminarUsuario(usuarioSeleccionado);

                // Eliminar el usuario de la lista observable
                listaUsuarios.remove(usuarioSeleccionado);

                // Mostrar una alerta de éxito
                mostrarAlerta("Éxito", "Usuario eliminado exitosamente.");
            }
        } else {
            // Si no se seleccionó ningún usuario, mostrar una alerta
            mostrarAlerta("Error", "Por favor, seleccione un usuario para eliminar.");
        }
    }

     private void mostrarAlerta(String titulo, String mensaje) {
        Alert alerta = new Alert(Alert.AlertType.INFORMATION);
        alerta.setTitle(titulo);
        alerta.setHeaderText(null);
        alerta.setContentText(mensaje);
        alerta.showAndWait();
    }

}
