package Controladores;

import ModeloDeClases.ClienteConexionB;
import ModeloDeClases.Libros;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class Agregar_Nuevos_LibrosController implements Initializable {

    @FXML
    private Button BotonDeRegreso;
    @FXML
    private TextField nombre;
    @FXML
    private TextField autor;
    @FXML
    private TextField ISBN;
    @FXML
    private TextField publicacion;
    @FXML
    private TextField editorial;
    @FXML
    private TextField cantidad;
    
    @FXML
    private Button CreacionDeLibro;

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    

    @FXML
    private void BotonRegresarApantallaPrincipal(ActionEvent event) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/InterfacesGraficas/Menu_Principal_Administrador.fxml"));
            Parent root = loader.load();
            Scene scene = new Scene(root);
            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            stage.setScene(scene);
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @FXML
    private void BotonAgregarLibroAlaBiblioteca(ActionEvent event) {
        String titulo = nombre.getText();
        String autorLibro = autor.getText();
        String isbn = ISBN.getText();
        String fechaPublicacion = publicacion.getText();
        String editorialLibro = editorial.getText();
        int cantidadLibro = Integer.parseInt(cantidad.getText());

        if (!titulo.isEmpty() && !autorLibro.isEmpty() && !isbn.isEmpty() && !fechaPublicacion.isEmpty() && !editorialLibro.isEmpty()) {
            Libros nuevoLibro = new Libros(titulo, autorLibro, isbn, fechaPublicacion, editorialLibro, cantidadLibro);
            ClienteConexionB conexion = new ClienteConexionB();
            conexion.insertarLibro(nuevoLibro);
            mostrarMensaje("Éxito", "Libro creado y agregado exitosamente.");
        } else {
            mostrarMensaje("Error", "Por favor, complete todos los campos.");
        }
    }

    private void mostrarMensaje(String titulo, String mensaje) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(titulo);
        alert.setHeaderText(null);
        alert.setContentText(mensaje);
        alert.showAndWait();
    }
}
