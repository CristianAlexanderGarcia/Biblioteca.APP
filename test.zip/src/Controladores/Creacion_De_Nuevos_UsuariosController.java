package Controladores;

import ModeloDeClases.ClienteConexionB;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class Creacion_De_Nuevos_UsuariosController implements Initializable {

    @FXML
    private Button BotonRegreso;
    @FXML
    private Button BotonCreacioU;
    @FXML
    private TextField nombre;
    @FXML
    private TextField apellido;
    @FXML
    private TextField direccion;
    @FXML
    private TextField telefono;
    @FXML
    private TextField identificador;

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    

    @FXML
    private void BotonRegresarApantallaPrincipal(ActionEvent event) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/InterfacesGraficas/Menu_Principal_Administrador.fxml"));
            Parent root = loader.load();
            Scene scene = new Scene(root);
            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            stage.setScene(scene);
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @FXML
private void BotonCrearUsuario(ActionEvent event) {
    String nombreUsuario = nombre.getText();
    String apellidoUsuario = apellido.getText();
    String direccionUsuario = direccion.getText();
    String telefonoUsuario = telefono.getText();
    String identificadorUsuario = identificador.getText();

    if (!nombreUsuario.isEmpty() && !apellidoUsuario.isEmpty() && !direccionUsuario.isEmpty() && !telefonoUsuario.isEmpty() && !identificadorUsuario.isEmpty()) {
        // Llamar al método insertarCliente de ClienteConexionB para guardar el nuevo usuario
        ClienteConexionB clienteConexion = new ClienteConexionB();
        clienteConexion.insertarCliente(nombreUsuario, apellidoUsuario, identificadorUsuario, direccionUsuario, telefonoUsuario);

        mostrarMensaje("Éxito", "Usuario creado y guardado exitosamente en la base de datos.");
    } else {
        mostrarMensaje("Error", "Por favor, complete todos los campos.");
    }
}


    private void mostrarMensaje(String titulo, String mensaje) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(titulo);
        alert.setHeaderText(null);
        alert.setContentText(mensaje);
        alert.showAndWait();
    }
}
