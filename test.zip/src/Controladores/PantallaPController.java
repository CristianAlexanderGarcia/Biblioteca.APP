package Controladores;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author ALEX
 */
public class PantallaPController implements Initializable {

    @FXML
    private Button BotonAdministrador;
    @FXML
    private Button botonCliente;

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    

    @FXML
    private void eventclickAdmin(ActionEvent event) {
        System.out.println("Botón Admin presionado");
    try {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("/InterfacesGraficas/Menu_Registro_Administrador.fxml"));
        Parent root = loader.load();
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    } catch (IOException e) {
        System.err.println("Error al cargar Menu_Registro_Administrador.fxml: " + e.getMessage());
        e.printStackTrace();
    }
}


   @FXML
private void eventclickCliente(ActionEvent event) {
    System.out.println("Botón Cliente presionado");
    try {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("/InterfacesGraficas/PantallaDeIngreso.fxml"));
        Parent root = loader.load();
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    } catch (IOException e) {
        System.err.println("Error al cargar PantallaDeIngreso.fxml: " + e.getMessage());
        e.printStackTrace();
    }
}
    }
