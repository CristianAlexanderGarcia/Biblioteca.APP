package Controladores;

import static ModeloDeClases.CConexion.conectar;
import ModeloDeClases.ClienteConexionB;
import static ModeloDeClases.ClienteConexionB.nombreUsuario;
import ModeloDeClases.Libros;
import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;
import java.util.ResourceBundle;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.TextInputDialog;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import javafx.util.Duration;

public class Menu_BusquedaController implements Initializable {

    @FXML
    private Button botonDeregresoP;
    @FXML
    private TableView<Libros> TablaDeBusqueda;

    @FXML
    private TableColumn<Libros, String> nombreColumn;
    @FXML
    private TableColumn<Libros, String> autorColumn;
    @FXML
    private TableColumn<Libros, String> ISBNColumn;
    @FXML
    private TableColumn<Libros, String> editorialColumn;
    @FXML
    private TableColumn<Libros, String> publicacionColumn;
    @FXML
    private TableColumn<Libros, Integer> cantidadColumn;

    private ClienteConexionB clienteConexionB;
    @FXML
    private TextField BarraDeBusqueda;
    @FXML
    private Button Filtro1Autor;
    @FXML
    private Button Filtroanio;
    @FXML
    private Button FiltroEditorial;
    @FXML
    private Button FiltroISBN;
    @FXML
    private Button FiltroTitulo;

    @FXML
    private Button botonParaRentar;

    private String textoBusquedaActual = ""; // Variable para almacenar el texto de búsqueda actual
    private int recordatoriosEnviados = 0;
    private boolean multaGenerada = false;
    private Timeline recordatorioTimeline;
    private Map<String, Integer> multasPorUsuario = new HashMap<>();
    private Map<String, Integer> cantidadAlquiladaPorUsuario = new HashMap<>();
    
    private int cantidadLibrosRentados;
    private int cantidadLibrosDevueltos;
    private int cantidadRecordatorios;
    private int cantidadMultasGeneradas;

    

    // Getters para las variables
    public int getCantidadLibrosRentados() {
        return cantidadLibrosRentados;
    }

    public int getCantidadLibrosDevueltos() {
        return cantidadLibrosDevueltos;
    }

    public int getCantidadRecordatorios() {
        return cantidadRecordatorios;
    }

    public int getCantidadMultasGeneradas() {
        return cantidadMultasGeneradas;
    }

    @FXML
    private void mostrarHistorial(ActionEvent event) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/InterfacesGraficas/Menu_Historial.fxml"));
            Parent root = loader.load();

            Menu_HistorialController historialController = loader.getController();
            historialController.setMenuBusquedaController(this);

            Scene scene = new Scene(root);
            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            stage.setScene(scene);
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }


    @Override
    public void initialize(URL url, ResourceBundle rb) {
        clienteConexionB = new ClienteConexionB(); // Crear una instancia de ClienteConexionB
        initializeTableColumns();
        cargarLibros();
    }

    private void initializeTableColumns() {
        nombreColumn.setCellValueFactory(new PropertyValueFactory<>("nombre"));
        autorColumn.setCellValueFactory(new PropertyValueFactory<>("autor"));
        ISBNColumn.setCellValueFactory(new PropertyValueFactory<>("ISBN"));
        editorialColumn.setCellValueFactory(new PropertyValueFactory<>("editorial"));
        publicacionColumn.setCellValueFactory(new PropertyValueFactory<>("publicacion"));
        cantidadColumn.setCellValueFactory(new PropertyValueFactory<>("cantidad"));
    }

    private void cargarLibros() {
        ObservableList<Libros> libros = clienteConexionB.obtenerLibros();
        TablaDeBusqueda.setItems(libros);
    }

    @FXML
    private void BotonParaRegresarAlInicio(ActionEvent event) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/InterfacesGraficas/Menu_PrincipalB.fxml"));
            Parent root = loader.load();
            Scene scene = new Scene(root);
            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            stage.setScene(scene);
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @FXML
    private void BotonParaFiltrarAutor(ActionEvent event) {
        ObservableList<TableColumn<Libros, ?>> columns = TablaDeBusqueda.getColumns();
        columns.remove(autorColumn);
        columns.add(0, autorColumn);
    }

    @FXML
    private void BotonParaFiltrarEditorial(ActionEvent event) {
        ObservableList<TableColumn<Libros, ?>> columns = TablaDeBusqueda.getColumns();
        columns.remove(editorialColumn);
        columns.add(0, editorialColumn);
    }

    @FXML
    private void BotonParaFiltrarISBN(ActionEvent event) {
        ObservableList<TableColumn<Libros, ?>> columns = TablaDeBusqueda.getColumns();
        columns.remove(ISBNColumn);
        columns.add(0, ISBNColumn);
    }

    @FXML
    private void BotonParaFiltrarPublicacion(ActionEvent event) {
        ObservableList<TableColumn<Libros, ?>> columns = TablaDeBusqueda.getColumns(); 
        columns.remove(publicacionColumn); 
        columns.add(0, publicacionColumn); 
    }

    @FXML
    private void BotonParaBuscarLibros(ActionEvent event) {
        String textoABuscar = BarraDeBusqueda.getText().trim().toLowerCase();

        ObservableList<Libros> librosFiltrados = FXCollections.observableArrayList();

        for (Libros libro : clienteConexionB.obtenerLibros()) {
            if (libro.getNombre().toLowerCase().contains(textoABuscar) ||
                libro.getAutor().toLowerCase().contains(textoABuscar) ||
                libro.getISBN().toLowerCase().contains(textoABuscar) ||
                libro.getEditorial().toLowerCase().contains(textoABuscar) ||
                String.valueOf(libro.getPublicacion()).contains(textoABuscar)) {
                librosFiltrados.add(libro);
            }
        }

        // Limpiar la tabla antes de agregar los resultados de búsqueda
        TablaDeBusqueda.getItems().clear();

        // Agregar los libros filtrados a la tabla
        TablaDeBusqueda.setItems(librosFiltrados);
    }

    @FXML
    private void BotonParaElTitulo(ActionEvent event) {
        ObservableList<TableColumn<Libros, ?>> columns = TablaDeBusqueda.getColumns();
        columns.remove(nombreColumn);
        columns.add(0, nombreColumn);
    }

    @FXML
    private void BotonParaRentarLibros(ActionEvent event) {
        // Mostrar un cuadro de diálogo para ingresar el identificador del usuario
        TextInputDialog dialog = new TextInputDialog();
        dialog.setTitle("Rentar libro");
        dialog.setHeaderText("Ingrese su identificador");
        dialog.setContentText("Identificador:");

        Optional<String> result = dialog.showAndWait();
        if (result.isPresent()) {
            String identificadorUsuario = result.get();

            // Verificar si el usuario tiene más de dos multas
            int multas = multasPorUsuario.getOrDefault(identificadorUsuario, 0);
            if (multas >= 2) {
                showAlert(Alert.AlertType.WARNING, "Alquiler no permitido", "No puede alquilar más libros hasta devolver los libros alquilados.");
                return;
            }

            // Verificar si el usuario tiene un libro alquilado
            boolean tieneLibroAlquilado = clienteConexionB.usuarioTieneLibroAlquilado(identificadorUsuario);
            if (tieneLibroAlquilado) {
                showAlert(Alert.AlertType.WARNING, "Alquiler no permitido", "No puede alquilar otro libro hasta que devuelva el libro alquilado.");
                iniciarRecordatorioDevolverLibro(identificadorUsuario);
                return;
            }

            // Mostrar un cuadro de diálogo para ingresar el nombre o ISBN del libro
            TextInputDialog dialogLibro = new TextInputDialog();
            dialogLibro.setTitle("Rentar libro");
            dialogLibro.setHeaderText("Ingrese el nombre o ISBN del libro");
            dialogLibro.setContentText("Nombre o ISBN:");

            Optional<String> resultLibro = dialogLibro.showAndWait();
            if (resultLibro.isPresent()) {
                String nombreOISBN = resultLibro.get();

                // Verificar si el libro existe en la base de datos
                boolean libroExiste = clienteConexionB.verificarExistenciaLibro(nombreOISBN);

                if (libroExiste) {
                    // Mostrar un cuadro de diálogo para ingresar la cantidad de libros a alquilar
                    TextInputDialog dialogCantidad = new TextInputDialog();
                    dialogCantidad.setTitle("Rentar libro");
                    dialogCantidad.setHeaderText("Ingrese la cantidad de libros a alquilar");
                    dialogCantidad.setContentText("Cantidad:");

                    Optional<String> resultCantidad = dialogCantidad.showAndWait();
                    if (resultCantidad.isPresent()) {
                        try {
                            int cantidad = Integer.parseInt(resultCantidad.get());

                            // Verificar si hay suficientes libros disponibles
                            Libros libroAlquilado = clienteConexionB.obtenerLibro(nombreOISBN);
                            if (libroAlquilado.getCantidad() < cantidad) {
                                showAlert(Alert.AlertType.ERROR, "Error", "No hay suficientes libros disponibles para alquilar.");
                                return;
                            }

                            // Reducir la cantidad de libros disponibles
                            libroAlquilado.setCantidad(libroAlquilado.getCantidad() - cantidad);
                            clienteConexionB.actualizarCantidadLibro(libroAlquilado);

                            // Mostrar mensaje de alquiler exitoso
                            showAlert(Alert.AlertType.INFORMATION, "Alquiler exitoso", "¡Felicidades! Ha alquilado el libro '" + libroAlquilado.getNombre() + "' con éxito.");

                            // Iniciar el timeline para el recordatorio de devolución del libro
                            iniciarRecordatorioDevolverLibro(identificadorUsuario);

                            // Guardar la cantidad alquilada por el usuario
                            cantidadAlquiladaPorUsuario.put(identificadorUsuario, cantidad);

                            // Actualizar el estado de alquiler del usuario
                            clienteConexionB.actualizarEstadoAlquilerUsuario(identificadorUsuario, true);
                        } catch (NumberFormatException e) {
                            showAlert(Alert.AlertType.ERROR, "Error", "Cantidad inválida. Por favor, ingrese un número válido.");
                        }
                    }
                } else {
                    // Mostrar mensaje de error si el libro no existe
                    showAlert(Alert.AlertType.ERROR, "Error", "El libro no existe en la base de datos.");
                }
            }
        }
    }

    private void iniciarRecordatorioDevolverLibro(String identificadorUsuario) {
        recordatoriosEnviados = 0;
        multaGenerada = false;

        // Detener cualquier timeline anterior
        if (recordatorioTimeline != null) {
            recordatorioTimeline.stop();
        }

        recordatorioTimeline = new Timeline(new KeyFrame(Duration.minutes(1), event -> {
            if (recordatoriosEnviados == 0) {
                // Mostrar primer recordatorio
                Alert alert = new Alert(Alert.AlertType.WARNING);
                alert.setTitle("Recordatorio");
                alert.setHeaderText(null);
                alert.setContentText("Tienes un minuto para devolver el libro en el almacén o se generará una multa.");
                alert.showAndWait();
            } else {
                // Mostrar recordatorio adicional
                Alert alert = new Alert(Alert.AlertType.WARNING);
                alert.setTitle("Recordatorio");
                alert.setHeaderText(null);
                alert.setContentText("Por favor, devuelva el libro antes de un minuto.");
                alert.showAndWait();
            }
            
            recordatoriosEnviados++;

            // Si se han enviado más de un recordatorio, generar una multa
            if (recordatoriosEnviados > 1 && !multaGenerada) {
                // Generar multa
                multaGenerada = true;
                recordatorioTimeline.stop(); // Detener el timeline

                Alert alertMulta = new Alert(Alert.AlertType.ERROR);
                alertMulta.setTitle("Multa generada");
                alertMulta.setHeaderText(null);
                alertMulta.setContentText("Se ha generado una multa por no devolver el libro a tiempo.");
                alertMulta.showAndWait();

                // Restaurar la cantidad de libros disponibles
                Libros libroAlquilado = clienteConexionB.obtenerLibroPorUsuario(identificadorUsuario);
                if (libroAlquilado != null) {
                    int cantidadAlquilada = cantidadAlquiladaPorUsuario.getOrDefault(identificadorUsuario, 0);
                    libroAlquilado.setCantidad(libroAlquilado.getCantidad() + cantidadAlquilada);
                    clienteConexionB.actualizarCantidadLibro(libroAlquilado);
                }

                // Actualizar el estado del usuario
                clienteConexionB.actualizarEstadoAlquilerUsuario(identificadorUsuario, false);
                // Aumentar el conteo de multas
                int multas = multasPorUsuario.getOrDefault(identificadorUsuario, 0);
                multasPorUsuario.put(identificadorUsuario, multas + 1);
            }
        }));

        recordatorioTimeline.setCycleCount(Timeline.INDEFINITE);
        recordatorioTimeline.play();
    }

    private void showAlert(Alert.AlertType alertType, String title, String message) {
        Alert alert = new Alert(alertType);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

   
}
