package Controladores;

import ModeloDeClases.ClienteConexionB;
import ModeloDeClases.Usuarios;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class Menu_UsuarioController implements Initializable {

    @FXML
    private TextField dato1;
    @FXML
    private TextField dato2;
    @FXML
    private TextField dato3;
    @FXML
    private TextField dato4;
    @FXML
    private TextField datoContra;
    @FXML
    private Button Regreso;

    private ClienteConexionB clienteDAO;
    private String identificadorUsuario;

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        clienteDAO = new ClienteConexionB();
    }

    public void setIdentificadorUsuario(String identificadorUsuario) {
        this.identificadorUsuario = identificadorUsuario;
        cargarDatosUsuario();
    }

    private void cargarDatosUsuario() {
        if (identificadorUsuario != null) {
            Usuarios usuario = clienteDAO.obtenerUsuario(identificadorUsuario);

            if (usuario != null) {
                dato1.setText(usuario.getNombre());
                dato2.setText(usuario.getApellido());
                dato3.setText(usuario.getTelefono());
                dato4.setText(usuario.getDireccion());
                datoContra.setText(usuario.getIdentificador());
            }
        }
    }

    @FXML
    private void RegresarAInicio(ActionEvent event) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/InterfacesGraficas/Menu_PrincipalB.fxml"));
            Parent root = loader.load();
            Scene scene = new Scene(root);
            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            stage.setScene(scene);
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
