package Controladores;

import static Controladores.PantallaDeIngresoController.identificadorUsuario;
import ModeloDeClases.ClienteConexionB;
import ModeloDeClases.Generadordecontraseña;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import javax.swing.JOptionPane;

public class Menu_Registro_AdministradorController implements Initializable {

    @FXML
    private Button BotonParaIngresar;
    @FXML
    private Button GenerarContra;
    @FXML
    private TextField IngresoNombre;
    @FXML
    private TextField IngresoApeliido;
    @FXML
    private TextField IngresoDireccion;
    @FXML
    private TextField IngresoTelefono;
    @FXML
    private TextField AgregarIdentificador;

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // Inicialización si es necesario
    }    

    @FXML
    private void ClickIngreso(ActionEvent event) throws IOException {
      String nombres = IngresoNombre.getText();
        String apellidos = IngresoApeliido.getText();
        String telefono = IngresoTelefono.getText();
        String direccion = IngresoDireccion.getText();
        String identificador = AgregarIdentificador.getText();

        if (nombres.isEmpty() || apellidos.isEmpty() || telefono.isEmpty() || direccion.isEmpty() || identificador.isEmpty()) {
            JOptionPane.showMessageDialog(null, "Llene todos los campos para entrar");
        } else {
            ClienteConexionB clienteDAO = new ClienteConexionB();
            clienteDAO.insertarCliente(nombres, apellidos, identificador, direccion, telefono);

            // Guardar el identificador en la variable estática
            identificadorUsuario = identificador;

            FXMLLoader loader = new FXMLLoader(getClass().getResource("/InterfacesGraficas/Menu_Principal_Administrador.fxml"));
            Parent root = loader.load();
            Scene scene = new Scene(root);
            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            stage.setScene(scene);
            stage.show();
        }
    }

    @FXML
    private void ClickGenerarContra(ActionEvent event) {
        String contrasena = Generadordecontraseña.generarContrasena();
        GenerarContra.setText(contrasena);
    }
    
}
