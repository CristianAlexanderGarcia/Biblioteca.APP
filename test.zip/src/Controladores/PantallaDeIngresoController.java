package Controladores;

import ModeloDeClases.ClienteConexionB;
import ModeloDeClases.Generadordecontraseña;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import javax.swing.JOptionPane;

public class PantallaDeIngresoController implements Initializable {

    @FXML
    private Button GenerarContraseña;
    @FXML
    private TextField ingresoNombre;
    @FXML
    private TextField ingresoApellidos;
    @FXML
    private TextField ingresoTelefono;
    @FXML
    private TextField ingresoDireccion;
    @FXML
    private Button Entrada;
    @FXML
    private TextField AgregarIdentificador;

    public static String identificadorUsuario; // Variable estática para almacenar el identificador

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }

    @FXML
    private void ClickGenerarContra(ActionEvent event) {
        String contrasena = Generadordecontraseña.generarContrasena();
        GenerarContraseña.setText(contrasena);
    }

    @FXML
    private void eventoclickEntrada(ActionEvent event) throws IOException {
        String nombres = ingresoNombre.getText();
        String apellidos = ingresoApellidos.getText();
        String telefono = ingresoTelefono.getText();
        String direccion = ingresoDireccion.getText();
        String identificador = AgregarIdentificador.getText();

        if (nombres.isEmpty() || apellidos.isEmpty() || telefono.isEmpty() || direccion.isEmpty() || identificador.isEmpty()) {
            JOptionPane.showMessageDialog(null, "Llene todos los campos para entrar");
        } else {
            ClienteConexionB clienteDAO = new ClienteConexionB();
            clienteDAO.insertarCliente(nombres, apellidos, identificador, direccion, telefono);

            // Guardar el identificador en la variable estática
            identificadorUsuario = identificador;

            FXMLLoader loader = new FXMLLoader(getClass().getResource("/InterfacesGraficas/Menu_PrincipalB.fxml"));
            Parent root = loader.load();
            Scene scene = new Scene(root);
            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            stage.setScene(scene);
            stage.show();
        }
    }
}
