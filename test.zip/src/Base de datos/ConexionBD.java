package ModeloDeClases;

import java.sql.Connection;

public class ConexionBD {
    public static void main(String[] args) {
        Connection conn = CConexion.conectar();
        if (conn != null) {
            System.out.println("Conexión establecida desde ConexionBD");

            DatosUsuarios datosUsuarios = new DatosUsuarios();

            // Guardar un usuario
            datosUsuarios.guardarUsuario("Juan", "Perez", "123456789", "Calle Falsa 123", "USER001");

            // Listar todos los usuarios
            datosUsuarios.listarUsuarios();

        } else {
            System.out.println("No se pudo establecer la conexión desde ConexionBD");
        }
    }
}
