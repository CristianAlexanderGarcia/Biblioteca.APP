package ModeloDeClases;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class DatosUsuarios {
    private final Connection conn;

    public DatosUsuarios() {
        conn = CConexion.conectar();
        if (conn == null) {
            System.out.println("No se pudo establecer la conexión a la base de datos.");
        }
    }

    public void guardarUsuario(String nombres, String apellidos, String telefono, String direccion, String identificador) {
        if (conn == null) {
            System.out.println("No se pudo establecer la conexión a la base de datos.");
            return;
        }

        String consulta = "INSERT INTO Usuario (nombres, apellidos, telefono, direccion, identificador) VALUES (?, ?, ?, ?, ?)";
        try (PreparedStatement statement = conn.prepareStatement(consulta)) {
            statement.setString(1, nombres);
            statement.setString(2, apellidos);
            statement.setString(3, telefono);
            statement.setString(4, direccion);
            statement.setString(5, identificador);

            statement.executeUpdate();
            System.out.println("Usuario guardado correctamente.");
        } catch (SQLException e) {
            System.out.println("Error al guardar usuario: " + e.getMessage());
            e.printStackTrace();
        }
    }

    public void listarUsuarios() {
        if (conn == null) {
            System.out.println("No se pudo establecer la conexión a la base de datos.");
            return;
        }

        String consulta = "SELECT * FROM Usuario";
        try (PreparedStatement statement = conn.prepareStatement(consulta);
             ResultSet resultSet = statement.executeQuery()) {

            while (resultSet.next()) {
                int idUsuario = resultSet.getInt("idusuario");
                String nombres = resultSet.getString("nombres");
                String apellidos = resultSet.getString("apellidos");
                String direccion = resultSet.getString("direccion");
                String telefono = resultSet.getString("telefono");
                String identificador = resultSet.getString("identificador");

                System.out.println("ID: " + idUsuario + ", Nombres: " + nombres + ", Apellidos: " + apellidos +
                                   ", Dirección: " + direccion + ", Teléfono: " + telefono + ", Identificador: " + identificador);
            }
        } catch (SQLException e) {
            System.out.println("Error al listar usuarios: " + e.getMessage());
            e.printStackTrace();
        }
    }
}
