package ModeloDeClases;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class DatosLibros {
    private final Connection conn;

    public DatosLibros() {
        conn = CConexion.conectar();
        if (conn == null) {
            System.out.println("No se pudo establecer la conexión a la base de datos.");
        }
    }

    public void guardarLibro(String nombre, String autor, String isbn, String publicacion, String editorial) {
        if (conn == null) {
            System.out.println("No se pudo establecer la conexión a la base de datos.");
            return;
        }

        String consulta = "INSERT INTO Libro (nombre, autor, isbn, publicacion, editorial) VALUES (?, ?, ?, ?, ?)";
        try (PreparedStatement statement = conn.prepareStatement(consulta)) {
            statement.setString(1, nombre);
            statement.setString(2, autor);
            statement.setString(3, isbn);
            statement.setString(4, publicacion);
            statement.setString(5, editorial);

            statement.executeUpdate();
            System.out.println("Libro guardado correctamente.");
        } catch (SQLException e) {
            System.out.println("Error al guardar libro: " + e.getMessage());
            e.printStackTrace(); // Añadido para más detalles del error
        }
    }
}
