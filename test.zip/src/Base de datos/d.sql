
CREATE TABLE Libro (
    idlibro SERIAL PRIMARY KEY,
    nombre VARCHAR(50) NOT NULL UNIQUE,
    autor VARCHAR(50),
    isbn VARCHAR(13) NOT NULL UNIQUE,
    publicacion DATE NOT NULL,
    editorial VARCHAR(50) NOT NULL
);


CREATE TABLE Cliente (
    idcliente SERIAL PRIMARY KEY,
    nombres VARCHAR(50) NOT NULL,
    apellidos VARCHAR(50) NOT NULL,
    identificador VARCHAR(50) NOT NULL UNIQUE,
    direccion VARCHAR(50) NOT NULL,
    telefono VARCHAR(50) NOT NULL,
);


CREATE TABLE Administrador (
    idadministrador SERIAL PRIMARY KEY,
    nombres VARCHAR(50) NOT NULL,
    apellidos VARCHAR(50) NOT NULL,
    identificador VARCHAR(50) NOT NULL UNIQUE,
    direccion VARCHAR(50) NOT NULL,
    telefono VARCHAR(50) NOT NULL
);


INSERT INTO Cliente (nombres, apellidos, identificador, direccion, telefono) 
VALUES ('Miguel José', 'García León', '2345431d', '5av. lote 4 zona 3. San Juan', '5434874');

SELECT * FROM Cliente;


INSERT INTO Libro (nombre, autor, isbn, publicacion, editorial) 
VALUES ('El viaje del tiempo', 'María López', '9781234567890', '2024-05-14', 'Horizontes Literarios');

SELECT * FROM Libro;

INSERT INTO Administrador (nombres, apellidos, identificador, direccion, telefono)
VALUES ('Ramon Miguel', 'Juarez Chajon', '03948544', '9av. zona 14 Cerro de la cruz', '7892449');

SELECT * FROM Administrador;


Select * From Administrador, Cliente, Libro;

Select * from Cliente;



