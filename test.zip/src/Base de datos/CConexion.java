package ModeloDeClases;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class CConexion {
    private static final String URL = "jdbc:mysql://aws-0-us-west-1.pooler.supabase.com:5432/Almacenamiento"; 
    private static final String USER = "postgres.idtuirfcvddgbxjhqnwp"; 
    private static final String PASSWORD = "garcia123"; 
    
    public static Connection conectar() {
        try {
            return DriverManager.getConnection(URL, USER, PASSWORD);
        } catch (SQLException e) {
            System.out.println("Error al conectar a la base de datos: " + e.getMessage());
            e.printStackTrace();
            return null;
        }
    }
}
