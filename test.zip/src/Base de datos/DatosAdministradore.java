package ModeloDeClases;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class DatosAdministradore {
    private final Connection conn;

    public DatosAdministradore() {
        conn = CConexion.conectar();
        if (conn == null) {
            System.out.println("No se pudo establecer la conexión a la base de datos.");
        }
    }

    public void guardarAdmin(String nombres, String apellidos, String telefono, String direccion, String identificador) {
        if (conn == null) {
            System.out.println("No se pudo establecer la conexión a la base de datos.");
            return;
        }

        String consulta = "INSERT INTO Cliente (nombres, apellidos, telefono, direccion, identificador) VALUES (?, ?, ?, ?, ?)";
        try (PreparedStatement statement = conn.prepareStatement(consulta)) {
            statement.setString(1, nombres);
            statement.setString(2, apellidos);
            statement.setString(3, telefono);
            statement.setString(4, direccion);
            statement.setString(5, identificador);

            statement.executeUpdate();
            System.out.println("Cliente guardado correctamente.");
        } catch (SQLException e) {
            System.out.println("Error al guardar cliente: " + e.getMessage());
            e.printStackTrace();
        }
    }

    public void listarClientes() {
        if (conn == null) {
            System.out.println("No se pudo establecer la conexión a la base de datos.");
            return;
        }

        String consulta = "SELECT * FROM Cliente";
        try (PreparedStatement statement = conn.prepareStatement(consulta);
             ResultSet resultSet = statement.executeQuery()) {

            while (resultSet.next()) {
                int idCliente = resultSet.getInt("idcliente");
                String nombres = resultSet.getString("nombres");
                String apellidos = resultSet.getString("apellidos");
                String direccion = resultSet.getString("direccion");
                String telefono = resultSet.getString("telefono");
                String identificador = resultSet.getString("identificador");

                System.out.println("ID: " + idCliente + ", Nombres: " + nombres + ", Apellidos: " + apellidos +
                                   ", Dirección: " + direccion + ", Teléfono: " + telefono + ", Identificador: " + identificador);
            }
        } catch (SQLException e) {
            System.out.println("Error al listar clientes: " + e.getMessage());
            e.printStackTrace();
        }
    }
}
